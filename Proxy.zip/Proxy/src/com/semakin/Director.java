package com.semakin;

public class Director implements IEmploye{
    private String name;
    private String salary;
    @Override
    public String getName() {
        return null;
    }

    @Override
    public void setName(String name) {

    }

    @Override
    public void setSalary(String salary) {

    }
}
