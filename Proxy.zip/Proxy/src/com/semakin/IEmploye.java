package com.semakin;

public interface IEmploye {
    String getName();
    void setName(String name);
    void setSalary(String salary);
}
